import React from 'react'
import Navbar from './Components/Navbar/Navbar'
import Hero from './Components/Hero/Hero'
import Neighborhoods from './Components/Neighborhoods/Neighborhoods'
import LoginForm from './Components/Login/Login'

const App = () => {
  return (
    <div>
      <Navbar/>
      <Hero/>
      <Neighborhoods/>
      <LoginForm>
        
      </LoginForm>
    </div>
  )
}

export default App
