import React from 'react'
import './Navbar.css'
const Navbar = () => {
  return (
    <nav className="navbar">
            <div className="logo">
                <img src="path/to/your/logo.png" alt="RENTIFY Logo" />
            </div>
            <input type="text" className="search-bar" placeholder="Search Properties, Areas..." />
            <ul className="navbar-links">
            <li><a href="#Home" class="nav-link">Home</a></li>
            <li><a href="#Agents" class="nav-link">Agents</a></li>
            <li><a href="#Neighborhoods" class="nav-link">Neighborhoods</a></li>
            <li><a href="#Testimonials" class="nav-link">Testimonials</a></li>
            <li><a href="#Contact" class="nav-link">Contact Us</a></li>
            </ul>
        <div class="navbar-buttons">
            <button class="login-button">Login</button>
        </div>
    </nav>
  )
}

export default Navbar
