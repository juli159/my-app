import React from 'react'
import './Hero.css'

const Hero = () => {
  return (
    <div className='hero'>
      <div className="hero-text">
        <h1>We ensure better solution of your desired problem</h1>
        <p>we simplify your search for the perfect rental property. 
            With a wide range of listings and user-friendly tools,
            we provide personalized,reliable, and efficient solutions to meet your unique needs.
             Let us help you find a place you'll love to call home.</p>
        <button className="btn">Explore more</button>

      </div>
    </div>
  )
}

export default Hero
