import React from 'react'
import './Neighborhoods.css'
import store1 from'../../assets/store1.jpg'
import store2 from '../../assets/store2.jpg'
import store3 from '../../assets/store3.jpg'

const Neighborhoods = () => {
  return (
    <div>
       <header>
                <h1>Neighborhoods</h1>
        </header>
        <main>
        <div id="neighborhoods">
          <h2>Featured Neighborhoods</h2>
          <div className="neighborhood">
            <h3>Example Neighborhood</h3>
            <p>Description of the neighborhood...</p>
            <a href="#neighborhood-details" className="btn">Explore More</a>
          </div>
          {/* Repeat for other neighborhoods */}
        </div>

        <div id="amenities">
          <h2>Amenities</h2>
          <div className="amenity">
            <h3>Grocery Stores</h3>
            <img src={store3} alt="" />
          </div>
          <div className="amenity">
            <h3>Grocery Stores</h3>
            <img src={store3} alt="" />
          </div>
          <div className="amenity">
            <h3>Grocery Stores</h3>
            <img src={store3} alt="" />
          </div>
        </div>

        <div id="transportation">
          <h2>Transportation</h2>
          <p>Map showing transportation options and major routes.</p>
          {/* Placeholder for map */}
        </div>

        <div id="reviews">
          <h2>Reviews</h2>
          <div className="review">
            <h3>John Doe</h3>
            <p>Great neighborhood! Very safe and close to amenities.</p>
          </div>
          {/* Add more reviews as needed */}
        </div>
      </main>
    </div>
  )
}

export default Neighborhoods
