import React, { useState } from 'react';
import './Login.css'; 

const LoginForm = ({ onClose }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [userType, setUserType] = useState('buyer'); 

  const handleRegister = (event) => {
    event.preventDefault();
    
    const userData = {
      firstName,
      lastName,
      email,
      phoneNumber,
      userType 
    };
    console.log('Registering user:', userData);
    
    setFirstName('');
    setLastName('');
    setEmail('');
    setPhoneNumber('');
    onClose(); 
  }

  return (
    <div className="login-form-container">
      <form className="login-form" onSubmit={handleRegister}>
        <h2>Register</h2>
        <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="First Name" required />
        <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Last Name" required />
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
        <input type="tel" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Phone Number" required />
        <div className="radio-group">
          <label>
            <input type="radio" name="userType" value="buyer" checked={userType === 'buyer'} onChange={() => setUserType('buyer')} />
            Buyer
          </label>
          <label>
            <input type="radio" name="userType" value="seller" checked={userType === 'seller'} onChange={() => setUserType('seller')} />
            Seller
          </label>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default LoginForm;
